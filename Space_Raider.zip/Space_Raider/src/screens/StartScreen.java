package screens;

import game.SpaceRaider;
import buttons.StartButton;

public class StartScreen {
	private SpaceRaider world;

	public StartScreen(SpaceRaider world) {
		this.world = world;
		createTitleCard();
		createStartButton();
	}

	private void createTitleCard() {
		TitleCard titleCard = new TitleCard();
		world.addGameObject(titleCard, (world.WORLDWIDTH / 2) - (titleCard.getWidth() / 2),
				(world.WORLDHEIGHT / 3) - (titleCard.getHeight() / 3));
	}

	private void createStartButton() {
		int fontSize = 30;
		StartButton startButton = new StartButton("START GAME", fontSize, world);
		world.addGameObject(startButton, (world.WORLDWIDTH / 2) - (startButton.getWidth() / 2),
				(world.WORLDHEIGHT / 2) - (startButton.getHeight() / 2));
	}

}
