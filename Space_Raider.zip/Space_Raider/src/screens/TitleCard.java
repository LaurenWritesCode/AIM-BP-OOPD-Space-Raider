package screens;

import game.SpaceRaider;
import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;

public class TitleCard extends SpriteObject {
	private static Sprite titleCardSprite = new Sprite(SpaceRaider.MEDIA_URL.concat("titleCard.png"));

	public TitleCard() {
		super(titleCardSprite);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

}
