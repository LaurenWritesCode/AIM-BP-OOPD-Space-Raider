package screens;

import buttons.RestartButton;
import game.Player;
import game.SpaceRaider;
import nl.han.ica.oopg.objects.TextObject;

public class EndScreen {
	private SpaceRaider world;
	private int fontSize = 30;
	private String scoreText;

	public EndScreen(SpaceRaider world) {
		this.world = world;
		createScoreboard();
		createRestartButton();
	}

	private void createScoreboard() {
		if(Player.getLives() == 0) {
			String scoreText = ("You lost! Your score is " + Player.getScore());
		} else {
			String scoreText = ("You won! Your score is " + Player.getScore());
		}
		ScoreBoard scoreboard = new ScoreBoard(world, scoreText);
		world.addGameObject(scoreboard, (world.WORLDWIDTH / 2) - (scoreboard.getWidth() / 2),
				(world.WORLDHEIGHT / 4) - (scoreboard.getHeight() / 4));
	}

	private void createRestartButton() {
		RestartButton restartButton = new RestartButton("RESTART GAME", fontSize, world);
		world.addGameObject(restartButton, (world.WORLDWIDTH / 2) - (restartButton.getWidth() / 2),
				((world.WORLDHEIGHT / 6 )* 4) - (restartButton.getHeight() / 2));
	}
}
