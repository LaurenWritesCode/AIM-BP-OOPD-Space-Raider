package screens;

import game.SpaceRaider;
import nl.han.ica.oopg.dashboard.Dashboard;
import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;
import nl.han.ica.oopg.objects.TextObject;

public class ScoreBoard extends SpriteObject {
	private static Sprite scoreBoardSprite = new Sprite(SpaceRaider.MEDIA_URL.concat("scoreBoard.png"));
	private int fontSize;
	private Dashboard scoreDashboard;
	private static TextObject scoreText;

	public ScoreBoard(SpaceRaider world, String score) {
		super(scoreBoardSprite);
		//createDashboard(100, 100, world, score);
	}

	private void createDashboard(int dashboardWidth, int dashboardHeight, SpaceRaider world, String score) {
		scoreDashboard = new Dashboard(this.getX() + 10, this.getY() + 10, dashboardWidth, dashboardHeight);
		scoreText = new TextObject(score, dashboardHeight / 4);
		scoreDashboard.addGameObject(scoreText);
		world.addDashboard(scoreDashboard);
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

}
