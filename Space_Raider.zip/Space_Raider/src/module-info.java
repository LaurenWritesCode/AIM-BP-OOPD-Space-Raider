module spaceRaider {
	requires oopg.full;
}