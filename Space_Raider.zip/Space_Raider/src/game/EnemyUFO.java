package game;

import java.util.List;

import nl.han.ica.oopg.collision.ICollidableWithGameObjects;
import nl.han.ica.oopg.objects.GameObject;
import nl.han.ica.oopg.objects.Sprite;

public class EnemyUFO extends Enemy implements ICollidableWithGameObjects {
	private SpaceRaider world;
	private static int value = 50;

	public EnemyUFO(SpaceRaider world) {
		super(world, new Sprite(SpaceRaider.MEDIA_URL.concat("greenUFO.png")), 150, new int[] {180}, value);
		this.world = world;
		setGravity(0.01f);
		System.out.println("ik ben hier: maak ufo");
	}

	@Override
	public void updateMovement() {
		setY(y + 1);
		setX((float) (100 * Math.sin(y * 3)));
	}

	@Override
	protected void removeEnemy() {
		world.deleteGameObject(this);
		System.out.println("ik ben hier: verwijder ufo");
	}

	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject g : collidedGameObjects) {
			if (g instanceof Meteorite) {
				((Meteorite) g).doMeteoriteActionForColisionWithEnemy(this);
			} else if (g instanceof Lazer) {
				((Lazer) g).doLazerAction(this);
			}
		}

	}
}

