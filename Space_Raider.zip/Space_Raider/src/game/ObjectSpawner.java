package game;

import java.util.Random;

import nl.han.ica.oopg.alarm.Alarm;
import nl.han.ica.oopg.alarm.IAlarmListener;
import nl.han.ica.oopg.objects.Sprite;

public class ObjectSpawner implements IAlarmListener {
	private Sprite meteoriteBig1 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_big1.png"));
	private Sprite meteoriteBig2 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_big2.png"));
	private Sprite meteoriteBig3 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_big3.png"));
	private Sprite meteoriteBig4 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_big4.png"));

	private Sprite meteoriteMedium1 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_med1.png"));
	private Sprite meteoriteMedium2 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_med2.png"));

	private Sprite meteoriteSmall1 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_small1.png"));

	private Sprite meteoriteTiny1 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_tiny1.png"));
	private Sprite meteoriteTiny2 = new Sprite(SpaceRaider.MEDIA_URL.concat("meteorBrown_tiny2.png"));

	private final float objectsPerSecond;
	private SpaceRaider world;
	private static Alarm alarm;

	public ObjectSpawner(SpaceRaider world, float objectsPerSecond) {
		this.objectsPerSecond = objectsPerSecond;
		this.world = world;
		startAlarm();
	}

	private void startAlarm() {
		alarm = new Alarm("New Object", 1 / objectsPerSecond);
		alarm.addTarget(this);
		alarm.start();
	}

	public static void stopAlarm() {
		alarm.stop();
	}

	@Override
	public void triggerAlarm(String alarmName) {
		Meteorite[] meteorites = { new Meteorite(meteoriteBig1, world), new Meteorite(meteoriteBig2, world),
				new Meteorite(meteoriteBig3, world), new Meteorite(meteoriteBig4, world),
				new Meteorite(meteoriteMedium1, world), new Meteorite(meteoriteMedium2, world),
				new Meteorite(meteoriteSmall1, world), new Meteorite(meteoriteTiny1, world),
				new Meteorite(meteoriteTiny2, world), };
		Enemy[] enemys = { new EnemyUFO(world), new EnemySpaceship(world) };

		Random generator = new Random();
		int randomIndexMeteorites = generator.nextInt(meteorites.length);
		int randomIndexEnemys = generator.nextInt(enemys.length);
		
		Random rand = new Random();

		int xMetereor = rand.nextInt(world.WORLDWIDTH - (int) meteorites[2].getWidth());
		int yMetereor = -150;
		world.addGameObject(meteorites[randomIndexMeteorites], xMetereor, yMetereor);

		int xEnemy = rand.nextInt(world.WORLDWIDTH - (int) enemys[1].getWidth());
		int yEnemy = -150;
		world.addGameObject(enemys[randomIndexEnemys], xEnemy, yEnemy);

		startAlarm();
	}

}

/*
 * switch (objectType) { case (0): //world.addGameObject(powerUps[randomIndex],
 * x, y); world.addGameObject(enemys[randomIndex], x, y); break; case (1):
 * world.addGameObject(meteorites[randomIndex], x, y); break; //case (2):
 * //world.addGameObject(enemys[randomIndex], x, y); //break;
 */
