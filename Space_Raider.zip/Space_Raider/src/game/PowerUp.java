package game;

import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;

public abstract class PowerUp extends SpriteObject {
	protected SpaceRaider world;
	
	public PowerUp(Sprite sprite, SpaceRaider world) {
		super(sprite);
		this.world = world;
	}
	
	public void delete(SpaceRaider world) {
		world.deleteGameObject(this);
	}
	
	public abstract void doPowerUpAction(Player player);
}
