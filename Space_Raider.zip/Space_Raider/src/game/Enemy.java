package game;

import java.util.List;

import nl.han.ica.oopg.collision.ICollidableWithGameObjects;
import nl.han.ica.oopg.objects.GameObject;
import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;

public abstract class Enemy extends SpriteObject implements ICollidableWithGameObjects {
	private SpaceRaider world;
	private int lazerTimer;
	private int lazerDelay;
	private int lazerAngle[];
	private int value;

	public Enemy(SpaceRaider world, Sprite sprite, int lazerDelay, int lazerAngle[], int value) {
		super(sprite);
		this.lazerDelay = lazerDelay;
		this.lazerAngle = lazerAngle;
		lazerTimer = 0;
		this.world = world;
		this.value = value;
	}

	@Override
	public void update() {
		// updateMovement();
		updateLazer();
	}

	public abstract void updateMovement();

	private  void updateLazer() {
		lazerTimer++;
		if (lazerTimer > lazerDelay) {
			lazerTimer = 0;
			for (int i = 0; i < lazerAngle.length; i++) {
				EnemyLazer.enemyLazerShot(getCenterX(), getY(), world, lazerAngle[i]);
			}
		}
	}

	protected abstract void removeEnemy();

	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject g : collidedGameObjects) {
			if (g instanceof Meteorite) {
				((Meteorite) g).doMeteoriteActionForColisionWithEnemy(this);
			} else if (g instanceof Lazer) {
				((Lazer) g).doLazerAction(this);
			}

		}
	}

	public int getValue() {
		return value;
	}
	
}
