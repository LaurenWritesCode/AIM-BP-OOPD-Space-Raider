package game;

import java.util.List;

import game.PowerUp;
import nl.han.ica.oopg.collision.ICollidableWithGameObjects;
import nl.han.ica.oopg.objects.GameObject;
import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;

public class Player extends SpriteObject implements ICollidableWithGameObjects {
	private SpaceRaider world;
	private static int lives;
	private static int score;
	private String name;
	private boolean hasPowerUp;

	public Player(SpaceRaider world) {
		super(new Sprite(SpaceRaider.MEDIA_URL.concat("player.png")));
		this.world = world;
		this.setLives(3);
	}

	@Override
	public void update() {

		if (lives <= 0) {
			world.endGame();

		} else if (lives > 3) {
			setLives(3);
		}

		if (getX() <= 0) {
			setxSpeed(0);
			setX(0);
		}
		if (getY() <= 0) {
			setySpeed(0);
			setY(0);
		}
		if (getX() + getWidth() >= world.WORLDWIDTH) {
			setxSpeed(0);
			setX(world.WORLDWIDTH - getWidth());
		}
		if (getY() + getHeight() >= world.WORLDHEIGHT) {
			setxSpeed(0);
			setY(world.WORLDHEIGHT - getHeight());
		}

		if (hasPowerUp) {
			LazerPowerUp.timePowerUp(this);
		}
	}

	@Override
	public void keyPressed(int keyCode, char key) {
		final char SPACE = ' ';
	
		final int speed = 4;
		if (keyCode == world.LEFT) {
			setDirectionSpeed(260, speed);
		} else if (keyCode == world.RIGHT) {
			setDirectionSpeed(90, speed);
		} else if (keyCode == world.UP) {
			setDirectionSpeed(0, speed);
		} else if (keyCode == world.DOWN) {
			setDirectionSpeed(180, speed);
		} else if (keyCode == SPACE) {
			PlayerLazer.playerLazerShot(getCenterX(), getY(), hasPowerUp, world);
		}
	}

	public void increaseLives(int newLives) {
		setLives(lives + newLives);
	}

	public void decreaseLives(int newLives) {
		setLives(lives - newLives);
	}

	private void setLives(int lives) {
		this.lives = lives;
	}

	public static int getLives() {
		return lives;
	}

	public static void increaseScore(int addition) {
		score = getScore() + addition;
		System.out.println(getScore());
	}

	public static void decreaseScore(int depletion) {
		score = getScore() - depletion;
		System.out.println(getScore());
	}

	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject g : collidedGameObjects) {
			if (g instanceof PowerUp) {
				((PowerUp) g).doPowerUpAction(this);
			} else if (g instanceof Meteorite) {
				((Meteorite) g).doMeteoriteAction(this);
			} else if (g instanceof Lazer) {
				decreaseLives(1);
				world.refreshDasboardText();
				world.deleteGameObject(g);
			}
		}
	}

	public static int getScore() {
		return score;
	}

	public void setHasPowerUp(boolean hasPowerUp) {
		this.hasPowerUp = hasPowerUp;
	}

	public void resetPlayer() {
		this.setLives(3);
		Player.score = 0;
	}
}
