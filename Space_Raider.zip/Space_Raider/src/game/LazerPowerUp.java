package game;

import nl.han.ica.oopg.objects.Sprite;

public class LazerPowerUp extends PowerUp {
	private static int lazerPowerUpTimer;
	private static int timePowerUpCanBeUsed;
	
	public LazerPowerUp(SpaceRaider world) {
		super(new Sprite(SpaceRaider.MEDIA_URL.concat("lazerPowerUp.png")), world);
		setGravity(0.01f);
		lazerPowerUpTimer = 0;
		timePowerUpCanBeUsed = 500;
	}

	@Override
	public void update() {
	}
	
	public static void timePowerUp(Player player) {
		lazerPowerUpTimer++;
		if (lazerPowerUpTimer > timePowerUpCanBeUsed) {
			player.setHasPowerUp(false);
		}
	}

	@Override
	public void doPowerUpAction(Player player) {
		player.setHasPowerUp(true);
		//player.increaseLazerOutput(extraLazersPerShot);
		world.deleteGameObject(this);
		System.out.println("lazer action done");
	}
}
