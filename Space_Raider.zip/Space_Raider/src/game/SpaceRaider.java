package game;

import buttons.RestartButton;
import buttons.StartButton;
import game.Player;
import nl.han.ica.oopg.dashboard.Dashboard;
import nl.han.ica.oopg.engine.GameEngine;
import nl.han.ica.oopg.objects.TextObject;
import nl.han.ica.oopg.sound.Sound;
import nl.han.ica.oopg.view.View;
import screens.EndScreen;
import screens.StartScreen;

public class SpaceRaider extends GameEngine {

	private static final long serialVersionUID = 1L;
	public final int WORLDWIDTH = 850;
	public final int WORLDHEIGHT = 850;
	
	private StartScreen startScreen;
	private EndScreen endScreen; 
	private Sound backgroundMusic;
	private static TextObject scoreText;
	private static TextObject livesText;
	private Dashboard scoreBoard;
	private Dashboard livesBoard;
	
	private PowerUpSpawner powerUpSpawner;
	// private MeteoriteSpawner meteoriteSpawner;
	// private EnemySpawner enemySpawner;
	private ObjectSpawner objectSpawner;

	private Player player;

	/* Deze regel maakt het makkelijker om te refereren naar je plaatjes.*/
	public static String MEDIA_URL = "src/SpaceRaider/media/";

	public static void main(String[] args) {
		SpaceRaider tw = new SpaceRaider();
		tw.runSketch();
	}

	@Override
	public void setupGame() {
		createView();
		startScreen = new StartScreen(this);
	}

	@Override
	public void update() {

	}

	private void createView() {
		View view = new View(WORLDWIDTH, WORLDHEIGHT);
		setView(view);
		size(WORLDWIDTH, WORLDHEIGHT);
		view.setBackground(loadImage(SpaceRaider.MEDIA_URL.concat("SpaceBackground.png")));
		loadBackgroundMusic();
	}

	private void loadBackgroundMusic() {
		backgroundMusic = new Sound(this, MEDIA_URL.concat("SpaceMusic.mp3"));
		backgroundMusic.loop(-1);
	}

	private void createDashboard(int dashboardWidth, int dashboardHeight) {
		scoreBoard = new Dashboard(0, 0, dashboardWidth, dashboardHeight);
		livesBoard = new Dashboard(0, dashboardHeight / 6, dashboardWidth, dashboardHeight);
		scoreText = new TextObject("Score: " + Player.getScore(), dashboardHeight / 4);
		livesText = new TextObject("Lives: " + Player.getLives(), dashboardHeight / 4);
		scoreText.setForeColor(255, 255, 255, 255);
		livesText.setForeColor(255, 255, 255, 255);
		scoreBoard.addGameObject(scoreText);
		livesBoard.addGameObject(livesText);
		addDashboard(scoreBoard);
		addDashboard(livesBoard);

		// Sprite lives = new Sprite(SpaceRaider.MEDIA_URL.concat("life.png"));
	}

	public void refreshDasboardText() {
		scoreText.setText("Score: " + Player.getScore());
		livesText.setText("Lives: " + Player.getLives());
	}

	private void createObjects() {
		player = new Player(this);
		addGameObject(player, (WORLDWIDTH / 2 - player.getCenterX()), WORLDHEIGHT - 2 * player.getHeight());
		createDashboard(WORLDWIDTH, 100);
	}

	private void createSpawners() {
		powerUpSpawner = new PowerUpSpawner(this, (float) 0.1);
		objectSpawner = new ObjectSpawner(this, (float) 0.9);
	}

	public void startGame() {
		deleteAllGameOBjects();
		createObjects();
		createSpawners();
	}

	public void endGame() {
		deleteAllGameOBjects();
		powerUpSpawner.stopAlarm();
		objectSpawner.stopAlarm();
		deleteAllDashboards(); 
		endScreen = new EndScreen(this);

		//deleteAllGameObjectsOfType(Dashboard.class);
		//deleteAllGameObjectsOfType(TextObject.class);

		// meteoriteSpawner.deleteSpawner();
		// deleteAllTextObject();
	}
	
	public void showEndScreen() {
		scoreText = new TextObject("Your score: " + Player.getScore(), WORLDHEIGHT / 50);
		scoreText.setForeColor(255, 255, 255, 255);
		addGameObject(scoreText, (WORLDWIDTH / 2 - scoreText.getCenterX()), WORLDHEIGHT - 2 * scoreText.getHeight(), 1);
		
	}

	public void resetGame() {
		player.resetPlayer();
		startGame(); 
	}
}