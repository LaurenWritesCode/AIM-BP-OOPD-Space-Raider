package game;

import nl.han.ica.oopg.objects.Sprite;

public class EnemyLazer extends Lazer{
	private static Sprite sprite = new Sprite(SpaceRaider.MEDIA_URL.concat("laserGreen.png"));

	public EnemyLazer(SpaceRaider world, int angle, float x, float y) {
		super(world, angle, sprite, x, y);
	}

	public static void enemyLazerShot(float x, float y, SpaceRaider world, int angle) {
		Lazer newLazer = new EnemyLazer(world, angle, x, y + 50);
		world.addGameObject(newLazer);
	}
	
	@Override
	public void update() {
	}

}