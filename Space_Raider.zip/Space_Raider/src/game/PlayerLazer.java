package game;

import nl.han.ica.oopg.objects.Sprite;

public class PlayerLazer extends Lazer {
	private static Sprite lazerSprite = new Sprite(SpaceRaider.MEDIA_URL.concat("laserRed.png"));

	public PlayerLazer(SpaceRaider worldint, int angle, float x, float y) {
		super(worldint, angle, lazerSprite, x, y);
	}

	@Override
	public void update() {
	}

	public static void playerLazerShot(float x, float y, boolean hasPowerUp, SpaceRaider world) {
		if (hasPowerUp) {
			Lazer newLazer1 = new PlayerLazer(world, 0, x - 10, y - 50);
			Lazer newLazer2 = new PlayerLazer(world, 0, x + 10, y - 50);
			world.addGameObject(newLazer1);
			world.addGameObject(newLazer2);
			System.out.println("speler heeft powerup");
		} else {
			Lazer newLazer = new PlayerLazer(world, 0, x, y - 50);
			world.addGameObject(newLazer);
		}
	}
}
