package game;

import java.util.List;

import nl.han.ica.oopg.collision.ICollidableWithGameObjects;
import nl.han.ica.oopg.objects.GameObject;
import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;

public abstract class Lazer extends SpriteObject implements ICollidableWithGameObjects {
	private SpaceRaider world;
	
	public Lazer(SpaceRaider worldint, int angle, Sprite sprite, float x, float y) {
		super(sprite);
		world = worldint;
		setFriction(0);
		setDirectionSpeed(angle, 10);
		setX(x);
		setY(y);
	}

	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject g : collidedGameObjects) {
			if (g instanceof Meteorite) {

			}
		}
	}

	public void doLazerAction(Meteorite meteorite) {
		world.deleteGameObject(this);
	}

	public void doLazerAction(Enemy enemy) {
		int enemyValue = enemy.getValue();
		world.deleteGameObject(this);
		world.deleteGameObject(enemy);
		if (getY() > 0) { // 
			Player.increaseScore(enemyValue);
			world.refreshDasboardText();
		}
	}

	public void doLazerAction(Player player) {

	}
}