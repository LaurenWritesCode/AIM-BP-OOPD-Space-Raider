package game;

import java.util.List;

import nl.han.ica.oopg.collision.ICollidableWithGameObjects;
import nl.han.ica.oopg.objects.GameObject;
import nl.han.ica.oopg.objects.Sprite;

public class EnemySpaceship extends Enemy implements ICollidableWithGameObjects {
	private SpaceRaider world;
	private static int value = 100;

	public EnemySpaceship(SpaceRaider world) {
		super(world, new Sprite(SpaceRaider.MEDIA_URL.concat("enemyShip.png")), 150, new int[] { 170, 190 }, value);
		this.world = world;
		setGravity(0.01f);
		System.out.println("ik ben hier: maak spaceship");
	}

	@Override
	public void updateMovement() {
		setY(y + 1);
		setX((float) (100 * Math.sin(y * 3)));
	}

	@Override
	protected void removeEnemy() {
		world.deleteGameObject(this);
	}

	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject g : collidedGameObjects) {
			if (g instanceof Meteorite) {
				((Meteorite) g).doMeteoriteActionForColisionWithEnemy(this);
			} else if (g instanceof Lazer) {
				((Lazer) g).doLazerAction(this);
			}
		}

	}
}
