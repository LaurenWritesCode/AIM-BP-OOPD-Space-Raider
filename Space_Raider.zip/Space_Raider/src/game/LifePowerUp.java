package game;

import nl.han.ica.oopg.objects.Sprite;

public class LifePowerUp extends PowerUp {

	private int newlives = 1;

	public LifePowerUp(SpaceRaider world) {
		super(new Sprite(SpaceRaider.MEDIA_URL.concat("lifePowerUp.png")), world);
		setGravity(0.01f);
	}

	@Override
	public void doPowerUpAction(Player player) {
		player.increaseLives(newlives);
		world.deleteGameObject(this);
		//world.refreshDashboard();
		System.out.println("life action done");
	}

	@Override
	public void update() {

	}
}
