package game;

import java.util.List;

import nl.han.ica.oopg.collision.ICollidableWithGameObjects;
import nl.han.ica.oopg.objects.GameObject;
import nl.han.ica.oopg.objects.Sprite;
import nl.han.ica.oopg.objects.SpriteObject;

public class Meteorite extends SpriteObject implements ICollidableWithGameObjects {
	private SpaceRaider world;
	// private Sprite meteoriteBig = new
	// Sprite(SpaceRaider.MEDIA_URL.concat("meteorBig.png"));

	public Meteorite(Sprite sprite, SpaceRaider world) {
		super(sprite);
		this.world = world;
		setGravity(0.01f);
	}

	public void doMeteoriteAction(Player player) {
		Player.decreaseScore(50);
		world.deleteGameObject(this);
		System.out.println("meteorite action done");
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

	public void doMeteoriteActionForColisionWithEnemy(Enemy enemy) {
		world.deleteGameObject(enemy);
	}

	@Override
	public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
		for (GameObject g : collidedGameObjects) {
			if (g instanceof Lazer) {
				((Lazer) g).doLazerAction(this);
			}

		}
	}
}