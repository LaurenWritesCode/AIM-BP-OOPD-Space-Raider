package game;

import java.util.Random;

import nl.han.ica.oopg.alarm.Alarm;
import nl.han.ica.oopg.alarm.IAlarmListener;

public class PowerUpSpawner implements IAlarmListener {
	private float powerUpsPerSecond;
	private SpaceRaider world;
	private static Alarm alarm;

	public PowerUpSpawner(SpaceRaider world, float powerUpsPerSecond) {
		this.powerUpsPerSecond = powerUpsPerSecond;
		this.world = world;
		startAlarm();
	}

	private void startAlarm() {
		alarm = new Alarm("New powerUp", 1 / powerUpsPerSecond);
		alarm.addTarget(this);
		alarm.start();
	}

	public void stopAlarm() {
		alarm.stop();
	}

	@Override
	public void triggerAlarm(String alarmName) {
		PowerUp[] powerUps = { new LifePowerUp(world), new LazerPowerUp(world) };
		Random generator = new Random();
		int randomIndex = generator.nextInt(powerUps.length);
		Random rand = new Random();

		int x = rand.nextInt(world.WORLDWIDTH - 20);
		int y = -150;
		world.addGameObject(powerUps[randomIndex], x, y);
		startAlarm();
	}

	public void deleteSpawner() {

	}
}
