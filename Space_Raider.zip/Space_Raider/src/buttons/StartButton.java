package buttons;

import game.SpaceRaider;

public class StartButton extends Button {
	
	public StartButton(String text, int fontSize, SpaceRaider world) {
		super(text, fontSize, world);
	}
	
	public StartButton(String text, int fontSize, int xSize, int ySize, SpaceRaider world) {
		super(text, fontSize, xSize, ySize, world);
	}

	@Override
	public void clickedButton(SpaceRaider world) {
		world.startGame();
	}

}
