package buttons;

import game.SpaceRaider;

public class RestartButton extends Button{

	public RestartButton(String text, int fontSize, SpaceRaider world) {
		super(text, fontSize, world);
	}

	@Override
	public void clickedButton(SpaceRaider world) {
		world.resetGame();
		world.getView().getViewport().setX(0);		
	}

}
